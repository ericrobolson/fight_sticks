                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2462027
Working Arcade 8-Way Restrictor Plate for Joystick sanwa by Animedia is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I got 4 way joystick for my arcade bartop and I wanted a 8 way restrictor plate, I did a search and I found nothing, only a 4 way joystick restrictor and an adapter, unfortunately my joystick didnt had the choice to adapt a 8 way restrictor, so I just combined the 4 way joystick restrictor to the 8 way adapter, and it worked!

I recommend to use a 8 millimeter brim, only if you have troubles with adhesion
I used PLA at 205c nozzle  and heatbed 60c
 

# Print Settings

Printer: CR-10
Rafts: Yes
Supports: No
Infill: 50%

# Post-Printing

if you have troubles with the fitting you can cut the 2 pins that sometimes dont fit

<iframe src="//www.youtube.com/embed/xIbpF2hbqbM" frameborder="0" allowfullscreen></iframe>